package rushbot;

import battlecode.common.RobotController;

public class AStar {
	
	public RobotController robot;
	public Tile[][] map;
	
	/**
	 * Creates a new robot controller.
	 * @param robot
	 */
	public AStar(RobotController robot) {
		this.robot = robot;
	}
	
}
