This is our entry for the 2013 BattleCode competition!
