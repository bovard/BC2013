package rushbot;

import battlecode.common.RobotController;
import battlecode.common.RobotType;
import rushbot.robot.Artillery;
import rushbot.robot.Generator;
import rushbot.robot.HQ;
import rushbot.robot.Soldier;
import rushbot.robot.Supplier;


/** The example funcs player is a player meant to demonstrate basic usage of the most common commands.
 * Robots will move around randomly, occasionally mining and writing useless messages.
 * The HQ will spawn soldiers continuously. 
 */
public class RobotPlayer {
	public static void run(RobotController rc) {
		RobotInformation info = new RobotInformation(rc);
		System.out.println(rc.getType());
		
		if (rc.getType() == RobotType.HQ) {
			new HQ(rc, info).run();
		} else if (rc.getType() == RobotType.SOLDIER) {
			new Soldier(rc, info).run();
		} else {
			if (rc.getType() == RobotType.ARTILLERY) {
				System.out.println("Running Artillery!");
				new Artillery(rc, info).run();
			} else if (rc.getType() == RobotType.GENERATOR) {
				System.out.println("Creating Generator!");
				new Generator(rc, info).run();
			} else if (rc.getType() == RobotType.SUPPLIER) {
				System.out.println("Creating Supplier!");
				new Supplier(rc, info).run();
			}
		}
		// fell out
		while(true) {
			rc.yield();
		}
	}
}
