package rushbot.behavior;

import battlecode.common.GameActionException;

public interface IComBehavior {
	public void comBehavior() throws GameActionException;
}
