package rushbot.behavior.artillery;

import rushbot.behavior.Behavior;
import rushbot.combat.ArtilleryShotCalculator;
import rushbot.robot.Artillery;
import battlecode.common.GameActionException;
import battlecode.common.GameObject;
import battlecode.common.RobotType;

public class ArtilleryShoot extends Behavior{
	
	protected Artillery robot;
	protected ArtilleryShotCalculator shotCalc;
	
	public ArtilleryShoot(Artillery robot) {
		super();
		this.robot = robot;
		shotCalc = new ArtilleryShotCalculator(robot);
	}

	@Override
	public void run() throws GameActionException {
		shotCalc.shoot();
	}

	@Override
	public boolean pre() {
		return robot.canShoot && robot.enemyNearby;
	}

}
