package rushbot.behavior.gen;

import rushbot.behavior.Behavior;
import rushbot.communication.Communicator;
import rushbot.robot.Generator;
import rushbot.robot.HQ;
import battlecode.common.Clock;
import battlecode.common.GameActionException;

public class GeneratorIdle extends Behavior {
	
	protected Generator robot;

	public GeneratorIdle(Generator robot) {
		super();
		this.robot = robot;
	}
	
	@Override
	public void run() throws GameActionException {
	}

	@Override
	public boolean pre() {
		return true;
	}

}