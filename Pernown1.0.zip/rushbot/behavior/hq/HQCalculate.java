package rushbot.behavior.hq;

import rushbot.behavior.Behavior;
import rushbot.behavior.soldier.SoldierSelector;
import rushbot.robot.HQ;
import battlecode.common.GameActionException;

public class HQCalculate extends Behavior {
	
	protected HQ robot;
	public boolean calculating;
	protected HQSelector parent;
	

	public HQCalculate(HQ robot) {
		super();
		this.robot = robot;
		calculating = true;
	}
	
	@Override
	public void start() { 
		
	}
	
	@Override
	public void run() throws GameActionException {
		//Spawns a soldier since its an "active" option so we can
		//use our time best.
		// -- SPAWNS a soldier intentionally to help make the calculation time problem better--
		//Will likely finish before next rc is active		
		
		//Calculates information about the map, strategy, ect. ect.
		robot.calculateEncamperSpots();
		calculating = false;
	}

	@Override
	public boolean pre() {
		return calculating;
	}

}