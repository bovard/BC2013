package rushbot.behavior.hq;

import rushbot.behavior.Behavior;
import rushbot.robot.HQ;
import battlecode.common.GameActionException;

public class HQIdle extends Behavior {
	
	protected HQ robot;

	public HQIdle(HQ robot) {
		super();
		this.robot = robot;
	}
	
	@Override
	public void run() throws GameActionException {
		
		if (!robot.encampmentSorter.finishBaseCalculation) {
			robot.encampmentSorter.calculate();
		} else {
		}
	}

	@Override
	public boolean pre() {
		return !robot.rc.isActive();
	}

}
