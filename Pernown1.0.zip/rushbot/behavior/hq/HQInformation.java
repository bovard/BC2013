package rushbot.behavior.hq;

public class HQInformation {

}
