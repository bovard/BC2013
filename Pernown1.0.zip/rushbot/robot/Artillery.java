package rushbot.robot;

import rushbot.communication.Communicator;
import rushbot.trees.ArtilleryTree;
import rushbot.RobotInformation;
import battlecode.common.Clock;
import battlecode.common.GameActionException;
import battlecode.common.GameObject;
import battlecode.common.Robot;
import battlecode.common.RobotController;
import battlecode.common.RobotType;

public class Artillery extends TeamRobot{
	public boolean canShoot;
	public Robot[] nearbyObjects;
	public boolean enemyNearby;
	public Robot[] enemiesNearby;
	public int artilleryRange;

	public Artillery(RobotController rc, RobotInformation info) {
		super(rc, info);
		tree = new ArtilleryTree(this);
		
		//The seed is for a possible end time strategy of changing the seed to
		//switch all channels.
		com.seedChannels(5, new int[] {
			Communicator.CHANNEL_ARTILLERY_COUNT
		});
		artilleryRange = RobotType.ARTILLERY.attackRadiusMaxSquared;
	}

	@Override
	public void environmentCheck() throws GameActionException {
		canShoot = rc.isActive();
		if (canShoot) {
			enemiesNearby = rc.senseNearbyGameObjects(Robot.class, artilleryRange, info.enemyTeam);
			enemyNearby = enemiesNearby.length > 0;
			
			if (enemyNearby) {
				nearbyObjects = rc.senseNearbyGameObjects(Robot.class, artilleryRange);
			}
		}

		if (Clock.getRoundNum() % HQ.HQ_COUNT_ROUND - 1 == 0) {
			com.increment(Communicator.CHANNEL_ARTILLERY_COUNT);
		}
	}

}
