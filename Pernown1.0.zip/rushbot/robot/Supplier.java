package rushbot.robot;

import rushbot.communication.Communicator;
import rushbot.trees.SupplierTree;
import rushbot.RobotInformation;
import battlecode.common.GameObject;
import battlecode.common.RobotController;

public class Supplier extends TeamRobot {
	public boolean canShoot;
	public GameObject[] nearbyObjects;
	public boolean enemyNearby;
	public GameObject[] enemiesNearby;

	public Supplier(RobotController rc, RobotInformation info) {
		super(rc, info);
		tree = new SupplierTree(this);
		com.seedChannels(5, new int[] { 
			Communicator.CHANNEL_SUPPLIER_COUNT
		});
	}

	@Override
	public void environmentCheck() {
		canShoot = rc.isActive();
		if (canShoot) {
			enemiesNearby = rc.senseNearbyGameObjects(GameObject.class, 81, info.enemyTeam);
			enemyNearby = enemiesNearby.length > 0;
			
			if (enemyNearby) {
				nearbyObjects = rc.senseNearbyGameObjects(GameObject.class, 81);
			}
		}
	}
}
