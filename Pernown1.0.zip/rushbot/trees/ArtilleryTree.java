package rushbot.trees;

import rushbot.behavior.artillery.ArtillerySelector;
import rushbot.robot.Artillery;

public class ArtilleryTree extends Tree {

	public ArtilleryTree(Artillery robot) {
		super(robot);
		current = new ArtillerySelector(robot);
	}

}
