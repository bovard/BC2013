package rushbot.trees;

import rushbot.behavior.gen.GeneratorSelector;
import rushbot.robot.Generator;

public class GeneratorTree extends Tree {

	public GeneratorTree(Generator robot) {
		super(robot);
		current = new GeneratorSelector(robot);
	}

}
