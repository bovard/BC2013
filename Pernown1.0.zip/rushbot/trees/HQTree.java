package rushbot.trees;

import rushbot.behavior.hq.HQSelector;
import rushbot.robot.HQ;

public class HQTree extends Tree {

	public HQTree(HQ robot) {
		super(robot);
		current = new HQSelector(robot);
	}
}
