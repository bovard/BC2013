package rushbot.trees;

import rushbot.behavior.soldier.SoldierSelector;
import rushbot.robot.Soldier;

public class SoldierTree extends Tree {

	public SoldierTree(Soldier robot) {
		super(robot);
		this.current = new SoldierSelector(robot);
	}
}
