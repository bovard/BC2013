package rushbot.trees;

import rushbot.behavior.supplier.SupplierSelector;
import rushbot.robot.Supplier;

public class SupplierTree extends Tree {

	public SupplierTree(Supplier robot) {
		super(robot);
		current = new SupplierSelector(robot);
	}

}
